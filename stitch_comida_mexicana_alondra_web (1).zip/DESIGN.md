---
name: Sabor & Tradición Alondra
colors:
  surface: '#fdf9f3'
  surface-dim: '#dddad4'
  surface-bright: '#fdf9f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3ed'
  surface-container: '#f1ede7'
  surface-container-high: '#ebe8e2'
  surface-container-highest: '#e6e2dc'
  on-surface: '#1c1c18'
  on-surface-variant: '#58423c'
  inverse-surface: '#31302d'
  inverse-on-surface: '#f4f0ea'
  outline: '#8b716a'
  outline-variant: '#dfc0b8'
  surface-tint: '#a73a19'
  primary: '#932c0b'
  on-primary: '#ffffff'
  primary-container: '#b44322'
  on-primary-container: '#ffe2da'
  inverse-primary: '#ffb5a0'
  secondary: '#7f5700'
  on-secondary: '#ffffff'
  secondary-container: '#fdba45'
  on-secondary-container: '#6f4b00'
  tertiary: '#2d5938'
  on-tertiary: '#ffffff'
  tertiary-container: '#45724e'
  on-tertiary-container: '#c2f5c8'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd1'
  primary-fixed-dim: '#ffb5a0'
  on-primary-fixed: '#3b0900'
  on-primary-fixed-variant: '#862202'
  secondary-fixed: '#ffdeae'
  secondary-fixed-dim: '#fdba45'
  on-secondary-fixed: '#281900'
  on-secondary-fixed-variant: '#604100'
  tertiary-fixed: '#bcefc3'
  tertiary-fixed-dim: '#a1d2a8'
  on-tertiary-fixed: '#00210b'
  on-tertiary-fixed-variant: '#23502f'
  background: '#fdf9f3'
  on-background: '#1c1c18'
  surface-variant: '#e6e2dc'
typography:
  display-lg:
    fontFamily: Epilogue
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Epilogue
    fontSize: 38px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Epilogue
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Epilogue
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Epilogue
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Epilogue
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
The design system channels the rich culinary heritage of Tecomán, Colima, translating authentic Mexican warmth, fresh coastal ingredients, and artisanal craft into an upscale, appetizing digital experience. The interface balances high-touch tradition with contemporary elegance—moving away from stereotypical kitsch and stepping into refined gastronomy.

The emotional core evokes the sensory comfort of slow-cooked recipes, roasted chiles, crisp garden produce, and homemade tortillas served on handcrafted barro. The design movement marries **Tactile Modernism** with an **Editorial Culinary** aesthetic: rich textural cues, organic rounded corners, natural warm illumination, fluid micro-interactions, and crisp modern typography that elevate comforting homestyle cooking into an exceptional culinary destination.

## Colors
The palette is rooted directly in authentic Mexican culinary elements:
- **Primary (`#B44322` - Terracota Asado):** An earthy, savory red-clay tone reminiscent of roasted tomatoes, dried guajillo chiles, and traditional clay cookware. Used for key call-to-actions, active indicators, and high-impact culinary focal points.
- **Secondary (`#D99B26` - Ocre Maíz Tostado):** A luminous golden hue echoing heirloom corn, golden plantains, and honeyed glaze. Used for highlights, culinary badges, ratings, and warmth accents.
- **Tertiary (`#3E6B48` - Verde Agave & Cilantro):** A balanced botanical green reflecting fresh limes, aromatic herbs, fresh jalapeño slices, and steamed garden vegetables. Used for vegetarian markers, fresh ingredient tags, and success notifications.
- **Neutral (`#FAF6F0` - Crema Maíz Nixtamal):** A warm, premium linen-cream canvas that eliminates clinical coldness, honoring the warmth of handmade corn dough and natural cotija cheese.

Contrast tokens ensure high readability: deep charcoal espresso (`#231B15`) acts as the primary text surface, while muted clay borders (`#E8DFD3`) provide delicate component separation without harshness.

## Typography
Typography is paired to convey both culinary distinction and seamless modern utility:
- **Epilogue** serves as the display and headline voice. Its geometric yet organic character channels contemporary Mexican editorial design, conveying craft, authority, and warmth across menu dish titles and signature section headings.
- **Plus Jakarta Sans** provides clarity and welcoming legibility across ingredient lists, pricing, preparation descriptions, and operational labels. Its soft curves complement the warmth of the brand without competing with display titles.

## Layout & Spacing
The layout follows a fluid 12-column grid on desktop and tablet, converting into a flexible 4-column flow on mobile viewports. Spacing is intentional and relaxed, honoring the unhurried ritual of Mexican dining:
- **Desktop (1024px+):** Fluid container with a max width of 1280px, utilizing generous 32px margins and 24px gutters to allow dish imagery and artisanal typography to breathe.
- **Tablet (768px - 1023px):** 8-column layout with 24px margins, reflowing food categories and plate options into dynamic two-column cards.
- **Mobile (<768px):** 4-column layout prioritizing tactile thumb zones, 16px lateral padding, and horizontal scroll carousels for daily specials, guarniciones (sides), and seasonal plates.

## Elevation & Depth
Depth mimics natural clay pottery bathed in ambient sunlight:
- **Tonal Layers:** Surfaces graduate from `#FAF6F0` (base canvas) to pure elevated cards in `#FFFFFF` with warm undertones.
- **Ambient Terracotta Shadows:** Shadows forgo clinical grey or cold black. Instead, they use low-density terracotta and espresso tints (`rgba(35, 27, 21, 0.06)` extending to `rgba(180, 67, 34, 0.08)` during interactions).
- **Subtle Organic Borders:** Cards and inputs carry a soft border tinted with warm sand (`#E8DFD3`) to maintain crisp separation against photographic imagery.
- **Micro-Motion Depth:** Cards subtly lift by 4px on hover accompanied by a smooth spring transition (`cubic-bezier(0.16, 1, 0.3, 1)`), evoking the anticipation of serving a fresh dish.

## Shapes
A roundedness level of 2 (`0.5rem` / 8px default, expanding to `1rem` / 16px for cards and dialogs, and full pills for badges) gives the interface a friendly, artisanal feel that reflects round earthenware, molcajetes, and hand-pressed corn tortillas. Edges remain structured enough to maintain a modern, elevated restaurant profile while avoiding mechanical sharp corners.

## Components
- **Buttons:**
  - *Primary:* Filled Terracota (`#B44322`) with bold cream typography (`#FAF6F0`). Rounded to 12px, accompanied by an ambient warm shadow and a 150ms gentle scale-down on active press.
  - *Secondary:* Cream background with a delicate border (`#E8DFD3`) and deep terracotta text, transitioning to pale agave tint on hover.
  - *Tertiary / Order Action:* Pill-shaped quick-add buttons with subtle icon triggers for custom salsa and side selections.
- **Menu Cards (Platillos):**
  - Designed with asymmetric photographic prominence: rich hero image occupying the top container, overlaid with high-contrast badge tags (e.g., "Especial del Día", "Receta Casera").
  - Includes ingredient callouts (chiles, guarniciones, arroz y frijoles refritos) in muted espresso body text and a clear price lockup in Epilogue Bold.
- **Chips & Filter Tabs:**
  - Pill-shaped filters for food categories (Desayunos, Carnes Asadas, Platillos Típicos, Bebidas Frescas).
  - Selected state: rich terracota fill with soft gold accent dot. Unselected state: warm linen fill with sand outline.
- **Inputs & Order Customization:**
  - Textured, warm-tinted form controls with generous touch heights (48px mobile, 44px desktop) for selecting tortilla type, salsa preference, or spice levels.
  - Active focus states introduce a distinct 2px ring in Ocre Maíz (`#D99B26`) with zero visual harshness.
- **Checkboxes & Radios:**
  - Custom rounded radio buttons mimicking traditional ceramic stamps; active check fills with Verde Agave (`#3E6B48`).
- **Interactive Motion Graphics:**
  - Subtle floating steam/aroma vector paths on featured hero plates.
  - Fluid order drawer opening with elastic spring dynamics, honoring the hospitality and warmth of authentic Colima cuisine.